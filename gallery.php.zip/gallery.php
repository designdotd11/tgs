


 <?php $this->load->view('web/include/header-home')?>
<link rel="stylesheet" href="<?= base_url('assets/web')?>/css/gallery.css" />

<?php if($banner){
    $url = base_url('uploads/banner/').$banner->image;
}else{
    $url = base_url('assets/web/images/Slide.jpg');
} ?>


<style>
    /* Gallery Grid */
.gallery-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 20px;
  margin-top: 20px;
}

.gallery-card {
  background: #fff;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0px 2px 8px rgba(0,0,0,0.1);
  transition: transform 0.3s;
  cursor: pointer;
  text-align: center;
}

.gallery-card:hover {
  transform: translateY(-5px);
}

.gallery-img img {
  width: 100%;
  height: 200px;
  object-fit: cover;
  display: block;
}

.gallery-title {
  padding: 10px;
  font-size: 16px;
  font-weight: 500;
  color: #333;
  text-align:center;
}
.gallery-card .gallery-title {
  text-align:center;
    
}





.lightbox {
  display: none;
  position: fixed;      /* Make it overlay, not block the page */
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0,0,0,0.8);
  justify-content: center;
  align-items: center;
  z-index: 9999;
}


html, body {
  height: auto !important;
  overflow-y: scroll !important;
}


/* Ensure selects can expand below even inside flex or card containers */
.d-flex {
  overflow: visible !important;
}

.form-select {
  position: relative;
  z-index: 1051;
  overflow: visible !important;
}

/* If inside a card or section with hidden overflow */
.card-body,
.container,
.section-content {
  overflow: visible !important;
}

/* Optional: nicer focus style */
select:focus {
  outline: none;
  box-shadow: 0 0 0 0.25rem rgba(2, 155, 190, 0.25);
}





</style>
 <section class="breadcrum-us-section top-space-subpage bottom-space" style="background-image: url('<?= base_url('assets/web')?>/images/27Media Coverage_Gallery.jpg');">
     <div class="breadcrum-overlay"></div>
     <div class="breadcrum-content">
         <h1 class="title-breadcrum">  Gallery </h1>
     </div>
 </section>

    <section class="pt-80 pb-80">
        <div class="container side-space">
            <div class="row">
                <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-5 col-sm-12">
                  <?php include('include/sidebar.php') ?>

                </div>
                <div class="col-xxl-9 col-xl-9 col-lg-8 col-md-7 col-sm-12" id="indusrty-box">
                    <div class="content-para  w-100 ps-lg-3 ps-xl-4 ps-xxl-3">
                        <div class="row">
                          <div class="col-xl-12 col-lg-12 col-sm-12 m-auto">
                            
                    
                    
                    <div class="d-flex flex-row align-items-center" style="overflow: visible; position: relative; z-index: 1051;">
                        <div class="me-2 position-relative" style="overflow: visible;">
                            <select id="categoryDropdown" class="form-select w-auto">
                                <option value="all" selected>All</option>
                                <?php foreach ($categories as $cat) { ?>
                                    <option value="<?= $cat->id ?>"><?= $cat->name ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    
                        <div class="position-relative" style="overflow: visible;">
                            <select id="yearDropdown" class="form-select w-auto ms-2">
                                <option value="all" selected>All Years</option>
                                <?php foreach ($years as $year) { ?>
                                    <option value="<?= $year ?>"><?= $year ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>



                    
                    
                           <div class="tab-content mt-4">
                            <div class="tab-pane active" id="sport">
                                <div id="result">
                                    <div class="gallery-grid">
                                        <?php 
                                        // Assuming $images is an array of images from the database or folder
                                        // Example: $images = ['img1.jpg', 'img2.jpg', 'img3.jpg'];
                                        foreach($images as $image): ?>
                                            <div class="gallery-card">
                                                <div class="gallery-img">
                                                    <img src="<?= base_url('uploads/gallery/' . $image['file_name']) ?>" alt="<?= htmlspecialchars($image['title']) ?>">
                                                </div>
                                                <p class="gallery-title"><?= htmlspecialchars($image['title']) ?></p>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        </div>
                        
                         <div class="lightbox">
                            <div class="lightbox-content">
                              <img id="lightbox-img" src="" alt="Lightbox Image">
                              <div class="lightbox-prev">&#10094;</div>
                              <div class="lightbox-next">&#10095;</div>
                            </div>
                          </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


 <!-- Footer -->
    
<?php $this->load->view('web/include/footer')?>


<script>
    // Function to save the selected category ID to localStorage
    function saveCategory(cat_id) {
        localStorage.setItem('selectedCategoryId', cat_id);
    } 
    // Function to filter the data based on category

function filter(cat_id) {
    $.ajax({
        url: "<?=base_url('Web/home/filter_gallery')?>",
        method: "POST",
        data: { cat_id: cat_id },
        success: function(response) {
            let rp;
            try {
                rp = JSON.parse(response);
            } catch (e) {
                console.error("Invalid JSON:", response);
                $('#result').html('<h3>Invalid server response</h3>');
                return;
            }

            if (rp.status == 1 && Array.isArray(rp.data) && rp.data.length > 0) {
                let html = '<div class="gallery-grid">';
                rp.data.forEach(function(item) {
                    if (!item.image) {
                        // skip card if no image
                        return;
                    }

                    let title = item.title && item.title.trim() !== "" ? item.title : "Untitled";

                    html += `
                        <div class="gallery-card">
                            <div class="gallery-img">
                                <img src="${item.image}" alt="${title}">
                            </div>
                            <p class="gallery-title">${title}</p>
                        </div>
                    `;
                });
                html += '</div>';
                $('#result').html(html);

                attachGalleryClickEvents();
            } else {
                $('#result').html('<h3>No Data Found !</h3>');
            }
        }
    });
}


// Attach click events to gallery items
function attachGalleryClickEvents() {
    const galleryItems = document.querySelectorAll('.gallery-card');
    const lightbox = document.querySelector('.lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    const lightboxPrev = document.querySelector('.lightbox-prev');
    const lightboxNext = document.querySelector('.lightbox-next');
    let currentIndex = 0;

    function showLightbox(index) {
        const imgSrc = galleryItems[index].querySelector('img').src;
        lightboxImg.src = imgSrc;
        lightbox.style.display = 'flex';
        currentIndex = index;
    }

    function hideLightbox() {
        lightbox.style.display = 'none';
    }

    function prevImage(event) {
        event.stopPropagation();
        currentIndex = (currentIndex > 0) ? currentIndex - 1 : galleryItems.length - 1;
        showLightbox(currentIndex);
    }

    function nextImage(event) {
        event.stopPropagation();
        currentIndex = (currentIndex < galleryItems.length - 1) ? currentIndex + 1 : 0;
        showLightbox(currentIndex);
    }

    galleryItems.forEach((item, index) => {
        item.addEventListener('click', () => showLightbox(index));
    });

    lightbox.addEventListener('click', hideLightbox);
    lightboxPrev.addEventListener('click', prevImage);
    lightboxNext.addEventListener('click', nextImage);
}

// Call attachGalleryClickEvents() on page load for the initial gallery items
// $(document).ready(function () {
//     var savedCatId = localStorage.getItem('selectedCategoryId');

//     if (savedCatId) {
//     $('.nav-link.tab-link').removeClass('active');
//     $('a.nav-link.tab-link[value="' + savedCatId + '"]').addClass('active');
//     if (savedCatId === 'all') {
//         showAllGallery();
//     } else {
//         filter(savedCatId);
//     }
// } else {
//     // Default to "All"
//     $('a.nav-link.tab-link[value="all"]').addClass('active');
//     showAllGallery();
// }


//     // Initial attach of click events
//     attachGalleryClickEvents();
// });

$(document).ready(function () {
    var savedCatId = localStorage.getItem('selectedCategoryId');

    if (savedCatId) {
        $('#categoryDropdown').val(savedCatId);
        if (savedCatId === 'all') {
            showAllGallery();
        } else {
            filter(savedCatId);
        }
    } else {
        $('#categoryDropdown').val('all');
        showAllGallery();
    }

    // On dropdown change
    $('#categoryDropdown').on('change', function() {
        var cat_id = $(this).val();
        saveCategory(cat_id);
        if (cat_id === 'all') {
            showAllGallery();
        } else {
            filter(cat_id);
        }
    });

    // Initial attach of click events
    attachGalleryClickEvents();
});



// Show all gallery images (static)
// function showAllGallery() {
//     $('#result').html(`
//         <div class="gallery-grid">
//             <div class="gallery-card">
//                 <div class="gallery-img">
//                     <img src="<?= base_url('uploads/gallery/img1.jpg') ?>" alt="Field Trip">
//                 </div>
//                 <p class="gallery-title">Field Trip</p>
//             </div>
//             <div class="gallery-card">
//                 <div class="gallery-img">
//                     <img src="<?= base_url('uploads/gallery/img2.jpg') ?>" alt="Sports Day">
//                 </div>
//                 <p class="gallery-title">Sports Day</p>
//             </div>
//             <!-- Add all your static gallery items -->
//         </div>
//     `);

//     attachGalleryClickEvents(); // re-bind click events
// }
function showAllGallery() {
    $('#result').html(`
        <div class="gallery-grid">
            <div class="gallery-card">
                <div class="gallery-img">
                    <img src="https://tgs.urips.co.in/uploads/gallery/image/1747200093Colouring-Competition%E2%80%93I.webp" alt="Field Trip">
                </div>
                <p class="gallery-title">Field Trip</p>
            </div>
            <div class="gallery-card">
                <div class="gallery-img">
                    <img src="https://tgs.urips.co.in/uploads/gallery/image/1747200093Colouring-Competition%E2%80%93I.webp" alt="Art drawn by students">
                </div>
                <p class="gallery-title">Art drawn by students</p>
            </div>
            <div class="gallery-card">
                <div class="gallery-img">
                    <img src="https://tgs.urips.co.in/uploads/gallery/image/1727506857dance-7.jpg" alt="Basketball game">
                </div>
                <p class="gallery-title">Basketball game</p>
            </div>
            <div class="gallery-card">
                <div class="gallery-img">
                    <img src="https://tgs.urips.co.in/uploads/gallery/image/1727506857dance-7.jpg" alt="Happy Moment">
                </div>
                <p class="gallery-title">Happy Moment</p>
            </div>
            <div class="gallery-card">
                <div class="gallery-img">
                    <img src="https://tgs.urips.co.in/uploads/gallery/image/1727506857dance-7.jpg" alt="Sports Day">
                </div>
                <p class="gallery-title">Sports Day</p>
            </div>
        </div>
    `);

    attachGalleryClickEvents(); // re-bind click events
}


</script>

   
