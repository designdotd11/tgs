
 <?php $this->load->view('web/include/header-home')?>
<!--FOR BANNER-->
<?php if($banner){
    $url = base_url('uploads/banner/').$banner->image;
}else{
    $url = base_url('assets/web/images/Slide.jpg');
} ?>

 <section class="breadcrum-us-section top-space-subpage bottom-space" style="background-image: url('<?= base_url('assets/web')?>/images/28Media Coverage_Video.jpg');">
     <div class="breadcrum-overlay"></div>
     <div class="breadcrum-content">
         <h1 class="title-breadcrum">  Video </h1>
         <p>Welcome to the Video Gallery of The Good Shepherd's (TGSS), showcasing the vibrant spirit of our school. Explore curated videos that highlight our educational philosophy, dynamic environment, and moments of learning, growth, and collaboration.</p>
     </div>
 </section>

     <section class="pt-80 pb-80">
        <div class="container side-space">
            <div class="row">
                <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-5 col-sm-12">
                  <?php include('include/sidebar.php') ?>

                </div>
                <div class="col-xxl-9 col-xl-9 col-lg-8 col-md-7 col-sm-12" id="indusrty-box">
                    <div class="content-para  w-100 ps-lg-3 ps-xl-4 ps-xxl-3">
                        <div class="row">
                            <?php foreach($videos as $video){?>
                            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                                 <div class="watch-card mb-4 ">
                                        <div class="video-card">
                                            <img src="<?= base_url('uploads/video/').$video->thumbnail?>" alt="<?= $video->title?>" class="thumbnail" data-id="1">
                                            <div class="video-overlay" data-id="1">
                                                <div class="play-icon-video" data-id="1">
                                                    <i class="fas fa-play"></i>
                                                </div>
                                            </div>
                                            <div class="video-container" data-id="1">
                                                <iframe class="youtube-video" data-id="1" width="500" height="680" src="<?= $video->video_url?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                                            </div>
                                        </div>
                                  </div>
                            </div>
                            <?php } ?>
                       </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



 <!-- Popup structure -->
 <div id="video-popup" class="video-popup">
     <div class="video-popup-content">
         <span class="video-close"><span style="margin-top: -5px;">&times;</span></span>
         <iframe id="popup-video" width="100%" height="100%" src="" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
     </div>
 </div>

<?php $this->load->view('web/include/footer')?>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/latest/TweenMax.min.js"></script>

<script>
     // Handle play icon click event
     document.querySelectorAll('.play-icon-video').forEach(item => {
             item.addEventListener('click', function() {
                 const videoId = this.getAttribute('data-id');
                 const videoSrc = document.querySelector(`.youtube-video[data-id="${videoId}"]`).src;
                 const popup = document.getElementById('video-popup');
                 const popupVideo = document.getElementById('popup-video');
                 popupVideo.src = videoSrc + '&autoplay=1';
                 popup.style.display = 'flex';
             });
         });

         // Close the popup
         document.querySelector('.video-popup .video-close').addEventListener('click', function() {
             const popup = document.getElementById('video-popup');
             const popupVideo = document.getElementById('popup-video');
             popupVideo.src = '';
             popup.style.display = 'none';
         });
</script>
